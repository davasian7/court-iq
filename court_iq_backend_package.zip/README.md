# COURT IQ — deploy starter (manual ITF refresh)

This package is intended to be deployed as a Node.js web service. It includes the Court IQ interface, an Express backend, a manual `POST /api/refresh` endpoint, snapshot storage and a change counter.

## Easiest next step
This package is not online yet. To publish it, it must be uploaded to a Git repository and connected to a host such as Render. That step requires your own accounts and explicit authorization.

## Run locally (optional)
- Install Node.js 20+
- Run `npm install`
- Run `npm start`
- Open `http://localhost:10000`

## Endpoints
- `GET /api/health`
- `GET /api/status`
- `GET /api/tournaments`
- `POST /api/refresh` — only triggered by pressing the UI button; no scheduled or automatic refresh.

## Data persistence warning
The starter writes `data/itf-calendar.json` to local disk. On many free cloud services the filesystem is temporary, so the saved snapshot may be lost on restart/redeploy. For persistent production use, configure a persistent database or storage volume. Do not assume free local-file storage is durable.

## Current limitations
- ITF HTML parsing is best-effort and has not been validated against a live response from the deployment environment. The ITF can change page markup or load data in the browser; in that case the endpoint reports an error and preserves the last saved snapshot.
- The current interface still displays the demo calendar until a live-source adapter is confirmed and connected to the table. The refresh endpoint returns counts and saves source records; the next development step is to map those records into the visible table.
- WTA calendar/rankings, entry lists, player performance, authentication and a production database are not implemented.
- This package is a starter, not a production-ready or publicly hosted website. Check the source's access terms and request limits before deployment.
