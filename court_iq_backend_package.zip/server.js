import express from "express";
import * as cheerio from "cheerio";
import fs from "node:fs/promises";
import path from "node:path";

const app = express();
const PORT = process.env.PORT || 10000;
const DATA_DIR = process.env.DATA_DIR || path.join(process.cwd(), "data");
const SNAPSHOT = path.join(DATA_DIR, "itf-calendar.json");
const ITF_URL = "https://www.itftennis.com/en/tournament-calendar/womens-world-tennis-tour-calendar/";

app.use(express.json({ limit: "100kb" }));
app.use(express.static("public"));

async function readSnapshot() {
  try { return JSON.parse(await fs.readFile(SNAPSHOT, "utf8")); }
  catch { return { tournaments: [], lastSuccessfulUpdate: null }; }
}
const normalize = s => (s || "").replace(/\s+/g, " ").trim();

function parseCalendar(html) {
  const $ = cheerio.load(html);
  const rows = [];
  // The ITF may change its markup. Try tables first; do not claim success on an empty parse.
  $("table tr").each((_, tr) => {
    const cells = $(tr).find("th,td").map((__, cell) => normalize($(cell).text())).get();
    if (cells.length < 4) return;
    const all = cells.join(" ").toLowerCase();
    if (all.includes("tournament") && all.includes("date") && all.includes("category")) return;
    const candidate = cells.find(x => /W(?:15|35|50|75|100|125)\b/i.test(x));
    if (!candidate) return;
    const name = cells[0];
    const date = cells.find(x => /\b\d{1,2}\s+[A-Za-z]{3,9}\s*[-–]\s*\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4}\b|\b\d{4}-\d{2}-\d{2}\b/.test(x)) || "";
    if (!name || !date) return;
    rows.push({
      id: [name,date,cells[2]||""].join("|").toLowerCase(),
      name, date,
      country: cells[2] || "",
      city: cells[3] || "",
      category: candidate.match(/W(?:15|35|50|75|100|125)\b/i)?.[0]?.toUpperCase() || "",
      prize: cells.find(x => /[$€£]\s?[\d,]+/.test(x)) || "",
      surface: cells.find(x => /\b(hard|clay|grass|carpet)\b/i.test(x)) || "",
      status: cells[cells.length-1] || "",
      sourceUrl: ITF_URL
    });
  });
  const seen = new Set();
  return rows.filter(row => { if (seen.has(row.id)) return false; seen.add(row.id); return true; });
}
function diff(previous, next) {
  const key = x => x.id || [x.name,x.date,x.city,x.category].join("|").toLowerCase();
  const oldMap = new Map(previous.map(x => [key(x),x]));
  const newMap = new Map(next.map(x => [key(x),x]));
  const added=[], changed=[], removed=[];
  for (const [k,v] of newMap) {
    if (!oldMap.has(k)) added.push(v);
    else if (JSON.stringify(oldMap.get(k)) !== JSON.stringify(v)) changed.push({before:oldMap.get(k),after:v});
  }
  for (const [k,v] of oldMap) if (!newMap.has(k)) removed.push(v);
  return {added,changed,removed};
}
app.get("/api/health", (_req,res)=>res.json({ok:true,service:"COURT IQ API"}));
app.get("/api/status", async (_req,res)=>{
  const s=await readSnapshot();
  res.json({source:ITF_URL,lastSuccessfulUpdate:s.lastSuccessfulUpdate,count:s.tournaments.length,hasSnapshot:s.tournaments.length>0});
});
app.get("/api/tournaments", async (_req,res)=>res.json(await readSnapshot()));
app.post("/api/refresh", async (_req,res)=>{
  const previous=await readSnapshot();
  try {
    const response=await fetch(ITF_URL,{headers:{"User-Agent":"COURT-IQ public calendar prototype contact: user initiated refresh","Accept":"text/html,application/xhtml+xml"},signal:AbortSignal.timeout(25000)});
    if(!response.ok) throw new Error(`ITF gaf HTTP ${response.status}`);
    const html=await response.text();
    const tournaments=parseCalendar(html);
    if(tournaments.length===0) throw new Error("De ITF-pagina is opgehaald, maar de kalenderparser vond geen herkenbare toernooien. De ITF kan de pagina client-side laden of de HTML-structuur hebben gewijzigd.");
    const changes=diff(previous.tournaments||[],tournaments);
    const lastSuccessfulUpdate=new Date().toISOString();
    const next={source:ITF_URL,lastSuccessfulUpdate,tournaments};
    await fs.mkdir(DATA_DIR,{recursive:true});
    const tmp=SNAPSHOT+".tmp";
    await fs.writeFile(tmp,JSON.stringify(next,null,2),"utf8");
    await fs.rename(tmp,SNAPSHOT);
    res.json({ok:true,...next,changes:{added:changes.added.length,changed:changes.changed.length,removed:changes.removed.length}});
  } catch(e) {
    res.status(502).json({ok:false,error:e.message||"Refresh mislukt",lastSuccessfulUpdate:previous.lastSuccessfulUpdate,count:(previous.tournaments||[]).length,previousSnapshotRetained:true});
  }
});
app.get("*",(_req,res)=>res.sendFile(path.join(process.cwd(),"public","index.html")));
app.listen(PORT,"0.0.0.0",()=>console.log(`COURT IQ listening on ${PORT}`));
